# Complete mushroom knowledge-graph reproducibility report

Pipeline version: 2.0.0
Random seed: 20260731
Bootstrap iterations: 5000

## Scope

This deterministic pipeline starts from checksum-verified, frozen study outputs. It does not query live bibliographic APIs, retrain BERTopic, call PubTator3, or download external NLP models. Those upstream and environment-dependent steps are intentionally separated so that the canonical validation rerun remains stable.

## Corpus summary

|   full_corpus_records |   eligible_include_or_partial_records |   year_min |   year_max |   research_domains |   chi_square_goodness_of_fit |   chi_square_P |   Shannon_entropy |   normalized_Shannon_entropy |
|----------------------:|--------------------------------------:|-----------:|-----------:|-------------------:|-----------------------------:|---------------:|------------------:|-----------------------------:|
|             2687.0000 |                             1868.0000 |  2000.0000 |  2025.0000 |             9.0000 |                    1395.1842 |         0.0000 |            1.8313 |                       0.8335 |

## Semantic graph

|   aggregated_typed_relations |   evidence_filtered_relations_support_ge_2 |   active_nodes |   active_directed_edges |   directed_density |   communities |   weighted_Louvain_modularity |
|-----------------------------:|-------------------------------------------:|---------------:|------------------------:|-------------------:|--------------:|------------------------------:|
|                     183.0000 |                                    86.0000 |        40.0000 |                 86.0000 |             0.0551 |        6.0000 |                        0.2817 |

## Temporal graph metrics

| period    |   year_start |   year_end |   nodes |   edges |   density |   transitivity |   modularity |   largest_connected_component_fraction |   communities |   assortativity |
|:----------|-------------:|-----------:|--------:|--------:|----------:|---------------:|-------------:|---------------------------------------:|--------------:|----------------:|
| 2000–2009 |         2000 |       2009 |      40 |      71 |    0.0455 |         0.0980 |       0.4033 |                                 0.9000 |             5 |         -0.3060 |
| 2010–2019 |         2010 |       2019 |      48 |     105 |    0.0465 |         0.1485 |       0.3391 |                                 0.9583 |             4 |         -0.2622 |
| 2020–2025 |         2020 |       2025 |      47 |     114 |    0.0527 |         0.1831 |       0.2463 |                                 0.9574 |             5 |         -0.2801 |

## Pathway score-stability analysis

| pathway_set                               |   n_pathways |   slope |   intercept |   R_squared |   P_value |
|:------------------------------------------|-------------:|--------:|------------:|------------:|----------:|
| Post-refinement outcome-aware pathway set |           52 |  0.2633 |      0.2978 |      0.8139 |    0.0000 |

## Independent blinded expert validation

| Validation task         |   n |   Correct |   Precision |   Precision_CI_low |   Precision_CI_high |   Agreement |   Cohen_kappa |   Kappa_CI_low |   Kappa_CI_high |   Kappa_bootstrap_valid |   Gwet_AC1 |   AC1_CI_low |   AC1_CI_high |   AC1_bootstrap_valid |
|:------------------------|----:|----------:|------------:|-------------------:|--------------------:|------------:|--------------:|---------------:|----------------:|------------------------:|-----------:|-------------:|--------------:|----------------------:|
| Entity recognition      | 300 |       290 |      0.9667 |             0.9397 |              0.9818 |      0.9700 |        0.1667 |        -0.0220 |          0.4937 |                    5000 |     0.9689 |       0.9471 |        0.9865 |                  5000 |
| Relation correctness    | 220 |       163 |      0.7409 |             0.6792 |              0.7943 |      0.8955 |        0.7183 |         0.6180 |          0.8137 |                    5000 |     0.8717 |       0.8177 |        0.9213 |                  5000 |
| Relation directionality | 220 |       195 |      0.8864 |             0.8376 |              0.9218 |      0.8591 |        0.0000 |         0.0000 |          0.0000 |                    5000 |     0.8379 |       0.7757 |        0.8950 |                  5000 |
| Pathway correctness     |  52 |        11 |      0.2115 |             0.1224 |              0.3403 |      1.0000 |        1.0000 |         1.0000 |          1.0000 |                    5000 |     1.0000 |       1.0000 |        1.0000 |                  5000 |
| Pathway directionality  |  52 |        16 |      0.3077 |             0.1991 |              0.4427 |      0.9808 |        0.9556 |         0.8506 |          1.0000 |                    5000 |     0.9661 |       0.8895 |        1.0000 |                  5000 |
| Outcome classification  |  52 |        19 |      0.3654 |             0.2480 |              0.5013 |      1.0000 |        1.0000 |         1.0000 |          1.0000 |                    5000 |     1.0000 |       1.0000 |        1.0000 |                  5000 |

## Candidate-level entity and relation benchmarks

| Analysis                               | Method                                 |   n_reference |   Recovered |   Rate |   CI_low |   CI_high |
|:---------------------------------------|:---------------------------------------|--------------:|------------:|-------:|---------:|----------:|
| Audited corrected reference            | Proposed framework                     |           294 |         294 | 1.0000 |   0.9871 |    1.0000 |
| Audited corrected reference            | SciSpacy en_core_sci_md 0.5.4 (frozen) |           294 |         292 | 0.9932 |   0.9755 |    0.9981 |
| Legacy manuscript-compatible reference | Proposed framework                     |           299 |         299 | 1.0000 |   0.9873 |    1.0000 |
| Legacy manuscript-compatible reference | SciSpacy en_core_sci_md 0.5.4 (frozen) |           299 |         292 | 0.9766 |   0.9525 |    0.9886 |

| Method                             | Endpoint                                       |   n |   Correct |   Rate |   CI_low |   CI_high |
|:-----------------------------------|:-----------------------------------------------|----:|----------:|-------:|---------:|----------:|
| Proposed ontology-guided framework | Adjudicated original-triple correctness        | 220 |       163 | 0.7409 |   0.6792 |    0.7943 |
| Proposed ontology-guided framework | Exact match to final corrected directed triple | 220 |       163 | 0.7409 |   0.6792 |    0.7943 |

| Method                       | Endpoint                                           |   n |   Predicted_positive |   Precision |   Recall |     F1 |
|:-----------------------------|:---------------------------------------------------|----:|---------------------:|------------:|---------:|-------:|
| Sentence-level co-occurrence | Binary validity of proposed candidate relationship | 220 |                  110 |      0.8000 |   0.5399 | 0.6447 |

| Method                  | Endpoint                                                          |   n |   Correct |   Rate |
|:------------------------|:------------------------------------------------------------------|----:|----------:|-------:|
| Type-pair majority rule | Exact corrected triple accuracy across all validation candidates  | 220 |       163 | 0.7409 |
| Type-pair majority rule | Exact corrected triple accuracy among relation-bearing gold items | 184 |       163 | 0.8859 |

## Held-out entity benchmark (proposed framework)

| analysis                         | system             | matching   | supported_classes                                           |   n_gold |   n_predictions |   TP |   FP |   FN |   precision |   precision_CI_low |   precision_CI_high |   recall |   recall_CI_low |   recall_CI_high |     F1 |   F1_CI_low |   F1_CI_high |
|:---------------------------------|:-------------------|:-----------|:------------------------------------------------------------|---------:|----------------:|-----:|-----:|-----:|------------:|-------------------:|--------------------:|---------:|----------------:|-----------------:|-------:|------------:|-------------:|
| COMMON_CORE                      | Proposed_framework | strict     | CHEMICAL;DISEASE                                            |      194 |             206 |  191 |   15 |    3 |      0.9272 |             0.8837 |              0.9657 |   0.9845 |          0.9592 |           1.0000 | 0.9550 |      0.9292 |       0.9773 |
| COMMON_CORE                      | Proposed_framework | relaxed    | CHEMICAL;DISEASE                                            |      194 |             206 |  191 |   15 |    3 |      0.9272 |             0.8842 |              0.9655 |   0.9845 |          0.9590 |           1.0000 | 0.9550 |      0.9300 |       0.9772 |
| BIONLP_SUPPORTED_SCHEMA          | Proposed_framework | strict     | CELL;CELL_LINE;CHEMICAL;DISEASE;GENE_PROTEIN;ORGAN;SPECIES  |      285 |             275 |  260 |   15 |   25 |      0.9455 |             0.9142 |              0.9738 |   0.9123 |          0.8719 |           0.9492 | 0.9286 |      0.9032 |       0.9519 |
| BIONLP_SUPPORTED_SCHEMA          | Proposed_framework | relaxed    | CELL;CELL_LINE;CHEMICAL;DISEASE;GENE_PROTEIN;ORGAN;SPECIES  |      285 |             275 |  260 |   15 |   25 |      0.9455 |             0.9145 |              0.9742 |   0.9123 |          0.8720 |           0.9481 | 0.9286 |      0.9030 |       0.9519 |
| PROPOSED_FULL_DOMAIN_DESCRIPTIVE | Proposed_framework | strict     | CHEMICAL;DISEASE;GENE_PROTEIN;MECHANISM;ORGAN;OTHER;SPECIES |      318 |             279 |  264 |   15 |   54 |      0.9462 |             0.9148 |              0.9743 |   0.8302 |          0.7798 |           0.8791 | 0.8844 |      0.8486 |       0.9190 |
| PROPOSED_FULL_DOMAIN_DESCRIPTIVE | Proposed_framework | relaxed    | CHEMICAL;DISEASE;GENE_PROTEIN;MECHANISM;ORGAN;OTHER;SPECIES |      318 |             279 |  264 |   15 |   54 |      0.9462 |             0.9154 |              0.9734 |   0.8302 |          0.7798 |           0.8777 | 0.8844 |      0.8478 |       0.9186 |

The external SciSpacy and PubTator3 runs are not part of the zero-download canonical path; their live execution remains an optional environment-specific audit.

## Held-out relation benchmark

| evaluation                              |   gold_relations |   predicted_relations |   TP |   FP |   FN |   precision |   recall |     F1 | review_provenance_note                                                                    |
|:----------------------------------------|-----------------:|----------------------:|-----:|-----:|-----:|------------:|---------:|-------:|:------------------------------------------------------------------------------------------|
| Surface-form strict                     |               56 |                    27 |   27 |    0 |   29 |      1.0000 |   0.4821 | 0.6506 | The S4 second review was AI-assisted and is not independent dual-human expert validation. |
| Ontology-aware endpoint sensitivity     |               56 |                    47 |   47 |    0 |    9 |      1.0000 |   0.8393 | 0.9126 | The S4 second review was AI-assisted and is not independent dual-human expert validation. |
| AI-assisted adjudicated gold correction |               49 |                    47 |   40 |    7 |    9 |      0.8511 |   0.8163 | 0.8333 | The S4 second review was AI-assisted and is not independent dual-human expert validation. |
| Conservative original-gold sensitivity  |               56 |                    40 |   40 |    0 |   16 |      1.0000 |   0.7143 | 0.8333 | The S4 second review was AI-assisted and is not independent dual-human expert validation. |

The S4 second review was AI-assisted and must not be described as independent human inter-rater validation.

## Co-occurrence versus semantic graph

|   cooccurrence_nodes |   cooccurrence_pairs |   semantic_pairs_support_ge_2 |   overlapping_pairs |   cooccurrence_unique_pairs |   semantic_unique_pairs |   pair_set_jaccard |   document_contexts_retained |
|---------------------:|---------------------:|------------------------------:|--------------------:|----------------------------:|------------------------:|-------------------:|-----------------------------:|
|              73.0000 |             191.0000 |                       86.0000 |             38.0000 |                    153.0000 |                 48.0000 |             0.1590 |                     845.0000 |

## Toxin representation

|   mapped_toxin_classes |   toxin_related_publications |   publication_concentration_HHI |   normalized_publication_entropy |   classes_below_10_percent_of_leader |
|-----------------------:|-----------------------------:|--------------------------------:|---------------------------------:|-------------------------------------:|
|                11.0000 |                     839.0000 |                          0.6325 |                           0.3774 |                               9.0000 |

## Expected-results audit

| status   |   checks |
|:---------|---------:|
| PASS     |       94 |

## Manuscript consistency audit

| issue                                         | current_manuscript_value                                            | recomputed_value                             | status                                          | explanation                                                                                                  |
|:----------------------------------------------|:--------------------------------------------------------------------|:---------------------------------------------|:------------------------------------------------|:-------------------------------------------------------------------------------------------------------------|
| Pair-set Jaccard                              | 0.122                                                               | 0.158996                                     | Manuscript correction required                  | 38 shared pairs / (191 + 86 - 38) = 0.158996.                                                                |
| Entity reference-concept denominator          | 299                                                                 | Audited corrected=294; legacy-compatible=299 | Report both or justify legacy handling          | Five rejected '(blank)' extractions have no real corrected reference concept.                                |
| Relation benchmark precision                  | 169/220 (76.8%)                                                     | 163/220 (0.7409)                             | Manuscript correction required                  | Correctness and directionality adjudication must be resolved separately.                                     |
| Aggregate versus temporal edge counts         | 86 aggregate edges; 114 edges in 2020–2025                          | Both reproduced                              | Explain different filters                       | The aggregate graph uses support_documents >= 2; temporal graphs include all unique period-specific triples. |
| Pathway validation versus refined pathway set | 11/52 initial-pathway correctness; R²=0.814 for 52 refined pathways | Both reproduced as separate sets             | Keep labels distinct                            | Stage VIII evaluates pre-refinement sampled candidates; the outcome-aware 52-path set is post-refinement.    |
| Held-out S4 reviewer provenance               | Not currently in main manuscript                                    | AI-assisted sensitivity audit                | Do not call independent human expert validation | Reviewer 1 is an author self-check and Reviewer 2 is AI-assisted.                                            |